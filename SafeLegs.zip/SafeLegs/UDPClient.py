# UDPClient.py
#
# Description: TODO
#
# Copyright (c) 2021
# Institute of Industrial Automation and Software Engineering
# University of Stuttgart
#
# Date of issue: TODO
#
# Version: 1.0
#
# Issuer: Marius Häcker

import socket
import struct
import threading
import sys


class UDPClient(threading.Thread):

    def __init__(self, serverIP, serverPort):
        """The constructor of the UDPClient"""
        threading.Thread.__init__(self)
        self.__stopFlag = False
        self.__receivedUDPMessages = 0
        self.__sock = self.buildUDPSocket(serverIP, serverPort)
        if(self.__sock == None): sys.exit(1)
        self.__timeValues = []
        self.__anglesLeftHip = []
        self.__anglesLeftKnee = []
        self.__anglesLeftAnkle = []
        self.__anglesRightHip = []
        self.__anglesRightKnee = []
        self.__anglesRightAnkle = []
        self.__rawPositionLeftHip = []
        self.__rawPositionLeftKnee = []
        self.__rawPositionLeftAnkle = []
        self.__rawPositionRightHip = []
        self.__rawPositionRightKnee = []
        self.__rawPositionRightAnkle = []
        

    def buildUDPSocket(self, serverIP, serverPort):
        """TODO""" #TODO
        try:            
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            server_address = (serverIP, serverPort)
            sock.bind(server_address)
        except socket.error:
            print("Error: building the UDP socket was not successful")
            sock = None
        return sock

    def run(self):
        """TODO""" #TODO
        while(self.__stopFlag == False):
            ID, newTimeValue, newSensorValues = self.receiveSensorData()
            if(ID == 0): continue
            #print("Received new sensor value with timestamp:", newTimeValue, "; values:")
            #for i in range(0, len(newSensorValues)-1):
                #print(newSensorValues[i])
            #print("Total number of received messages:", self.__receivedUDPMessages)
            elif ID == 1:
                self.__timeValues.append(newTimeValue)
                self.__anglesLeftHip.append(newSensorValues[0])
                self.__anglesLeftKnee.append(newSensorValues[1])
                self.__anglesLeftAnkle.append(newSensorValues[2])
                self.__anglesRightHip.append(newSensorValues[3])
                self.__anglesRightKnee.append(newSensorValues[4])
                self.__anglesRightAnkle.append(newSensorValues[5])
            elif ID == 2:
                self.__timeValues.append(newTimeValue)
                self.__rawPositionLeftHip.append(newSensorValues[0])
                self.__rawPositionLeftKnee.append(newSensorValues[1])
                self.__rawPositionLeftAnkle.append(newSensorValues[2])
                self.__rawPositionRightHip.append(newSensorValues[3])
                self.__rawPositionRightKnee.append(newSensorValues[4])
                self.__rawPositionRightAnkle.append(newSensorValues[5])

    def receiveSensorData(self):
        """TODO""" #TODO
        self.__sock.settimeout(1)       #a timer is set so that the recvfrom() can be interrupted if there is no data to be received
        try:
            message, addr = self.__sock.recvfrom(200)
            self.__receivedUDPMessages = self.__receivedUDPMessages + 1
            messageString = str(message)
            if len(messageString) > 100: print("Error:incorrect data received" + len(messageString))
            messageString = messageString.split("'")[1]
            IDString = messageString.split(';', 1)[0]
            ID = int(IDString)
            quantityString = messageString.split(';', 2)[1]
            quantity = int(quantityString)
            #print(quantityString)
            timeString = messageString.split(';', quantity + 1)[2]
            sensorData = [0 for element in range(quantity + 1)]
            for i in range(0, quantity):
                if ID == 1:
                    sensorData[i] = float(messageString.split(';', quantity + 2)[i + 3])
                elif ID == 2:
                    sensorData[i] = int(messageString.split(';', quantity + 2)[i + 3])
            time = float(timeString)
            return ID, time, sensorData
        except:
            return 0, 0, []
    
    def getTimeValues(self):
        return self.__timeValues

    def getAnglesLeftHip(self):
        return self.__anglesLeftHip
    
    def getAnglesLeftKnee(self):
        return self.__anglesLeftKnee

    def getAnglesLeftAnkle(self):
        return self.__anglesLeftAnkle

    def getAnglesRightHip(self):
        return self.__anglesRightHip

    def getAnglesRightKnee(self):
        return self.__anglesRightKnee

    def getAnglesRightAnkle(self):
        return self.__anglesRightAnkle

    def getRawPositionLeftHip(self):
        return self.__rawPositionLeftHip
    
    def getRawPositionLeftKnee(self):
        return self.__rawPositionLeftKnee

    def getRawPositionLeftAnkle(self):
        return self.__rawPositionLeftAnkle

    def getRawPositionRightHip(self):
        return self.__rawPositionRightHip

    def getRawPositionRightKnee(self):
        return self.__rawPositionRightKnee

    def getRawPositionRightAnkle(self):
        return self.__rawPositionRightAnkle

    def stop(self):
        self.__stopFlag = True
        print("Stopped")

    def getReceivedUDPMessages(self):
        return self.__receivedUDPMessages
        



