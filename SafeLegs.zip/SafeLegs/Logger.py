import csv
import threading
import time

class Logger(threading.Thread):
    def __init__(self, client, valuetype):
        threading.Thread.__init__(self)
        self.__udpClient = client
        self.__valuetype = valuetype
        self.__iterator = 0
        self.__tempIterator = 0
        self.__stopFlag = False

    def run(self):
        self.startLogging()

    def createFilename(self):
        currentTime = time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime(time.time()))
        filename = self.__valuetype + currentTime + ".csv"
        return filename

    def startLogging(self):
        with open(self.createFilename(), "w", newline='') as logFile:
            writer = csv.writer(logFile)
            while(self.__stopFlag == False):
                if self.__valuetype == "angle":
                    timeValues = self.__udpClient.getTimeValues()
                    valuesLeftHip = self.__udpClient.getAnglesLeftHip()
                    valuesLeftKnee = self.__udpClient.getAnglesLeftKnee()
                    valuesLeftAnkle = self.__udpClient.getAnglesLeftAnkle()
                    valuesRightHip = self.__udpClient.getAnglesRightHip()
                    valuesRightKnee = self.__udpClient.getAnglesRightKnee()
                    valuesRightAnkle = self.__udpClient.getAnglesRightAnkle()
                elif self.__valuetype == "raw_position":
                    timeValues = self.__udpClient.getTimeValues()
                    valuesLeftHip = self.__udpClient.getRawPositionLeftHip()
                    valuesLeftKnee = self.__udpClient.getRawPositionLeftKnee()
                    valuesLeftAnkle = self.__udpClient.getRawPositionLeftAnkle()
                    valuesRightHip = self.__udpClient.getRawPositionRightHip()
                    valuesRightKnee = self.__udpClient.getRawPositionRightKnee()
                    valuesRightAnkle = self.__udpClient.getRawPositionRightAnkle()
                print(len(timeValues))
                if(len(timeValues) > self.__iterator):
                    for i in range(self.__iterator, len(timeValues)):
                        self.__tempIterator = self.__tempIterator + 1
                        writer.writerow([timeValues[i], valuesLeftHip[i], valuesLeftKnee[i], valuesLeftAnkle[i], valuesRightHip[i], valuesRightKnee[i], valuesRightAnkle[i]])
                        logFile.flush()
                    self.__iterator = self.__tempIterator
                time.sleep(1)
            logFile.close()
            print("logger exit")

    def stopLogging(self):
        self.__stopFlag = True
        
        
