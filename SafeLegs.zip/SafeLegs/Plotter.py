import matplotlib.pyplot as plt
import threading
from queue import Queue
from matplotlib.animation import FuncAnimation
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib.widgets



class Plotter():
    
    def __init__(self, udpclient, valuetype):
        self.__firstValueReceived = False
        self.__udpClient = udpclient
        self.__valuetype = valuetype
        self.__stopFlag = False
        self.__timeZero = 0.0       #variable to store the value of the firstly received timestamp
        self.__xWindowSize = 1000
        self.__fig = plt.figure(figsize=(12, 8))
        self.__sub1 = self.__fig.add_subplot(321)
        self.__sub2 = self.__fig.add_subplot(322)
        self.__sub3 = self.__fig.add_subplot(323)
        self.__sub4 = self.__fig.add_subplot(324)
        self.__sub5 = self.__fig.add_subplot(325)
        self.__sub6 = self.__fig.add_subplot(326)
        self.__sub1.set_autoscale_on(True)
        self.__sub2.set_autoscale_on(True)
        self.__sub3.set_autoscale_on(True)
        self.__sub4.set_autoscale_on(True)
        self.__sub5.set_autoscale_on(True)
        self.__sub6.set_autoscale_on(True)
        self.__ln1, = self.__sub1.plot([], [], linestyle='None', marker = 'o', markersize=1, alpha=1)
        self.__ln2, = self.__sub2.plot([], [], linestyle='None', marker = 'o', markersize=1, alpha=1)
        self.__ln3, = self.__sub3.plot([], [], linestyle='None', marker = 'o', markersize=1, alpha=1)
        self.__ln4, = self.__sub4.plot([], [], linestyle='None', marker = 'o', markersize=1, alpha=1)
        self.__ln5, = self.__sub5.plot([], [], linestyle='None', marker = 'o', markersize=1, alpha=1)
        self.__ln6, = self.__sub6.plot([], [], linestyle='None', marker = 'o', markersize=1, alpha=1)

    def startPlotting(self):
        self.__ani = FuncAnimation(self.__fig, self.updatePlot, init_func = self.initPlot, blit=False, interval=50, repeat=True)
        #plt.show()   

    def initPlot(self):
        if self.__valuetype == "angle":
            self.__sub1.set_ylim(-1.0, 1.0)
            self.__sub1.set_ylabel("angle left hip")
            self.__sub2.set_ylim(-1.0, 1.0)
            self.__sub2.set_ylabel("angle left knee")
            self.__sub3.set_ylim(-1.0, 1.0)
            self.__sub3.set_ylabel("angle left ankle")
            self.__sub4.set_ylim(-1.0, 1.0)
            self.__sub4.set_ylabel("angle right hip")
            self.__sub5.set_ylim(-1.0, 1.0)
            self.__sub5.set_ylabel("angle right knee")
            self.__sub6.set_ylim(-1.0, 1.0)
            self.__sub6.set_ylabel("angle right ankle")
        elif self.__valuetype == "raw_position":
            self.__sub1.set_ylim(-50000.0, 50000.0)
            self.__sub1.set_ylabel("position left hip (raw)")
            self.__sub2.set_ylim(-50000.0, 50000.0)
            self.__sub2.set_ylabel("position left knee (raw)")
            self.__sub3.set_ylim(-50000.0, 50000.0)
            self.__sub3.set_ylabel("position left ankle (raw)")
            self.__sub4.set_ylim(-50000.0, 50000.0)
            self.__sub4.set_ylabel("position right hip (raw)")
            self.__sub5.set_ylim(-50000.0, 50000.0)
            self.__sub5.set_ylabel("position right knee (raw)")
            self.__sub6.set_ylim(-50000.0, 50000.0)
            self.__sub6.set_ylabel("position right ankle (raw)")
        plt.tight_layout()
        return self.__ln1, self.__ln2, self.__ln3, self.__ln4, self.__ln5, self.__ln6,
    
    def updatePlot(self, i):
        if(self.__stopFlag == True): 
            self.__ani.event_source.stop()
        timeValues = self.__udpClient.getTimeValues()
        if timeValues != [] and self.__firstValueReceived == False:      #executed one time when the first values have been received
            self.__timeZero = timeValues[0]
            self.__firstValueReceived = True
        if self.__valuetype == "angle":
            anglesLeftHip = self.__udpClient.getAnglesLeftHip()
            anglesLeftKnee = self.__udpClient.getAnglesLeftKnee()
            anglesLeftAnkle = self.__udpClient.getAnglesLeftAnkle()
            anglesRightHip = self.__udpClient.getAnglesRightHip()
            anglesRightKnee = self.__udpClient.getAnglesRightKnee()
            anglesRightAnkle = self.__udpClient.getAnglesRightAnkle()
        
            self.__ln1.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(anglesLeftHip, self.__xWindowSize))       #the time axis is mapped to begin with "0.0" for the first sensor value
            self.__ln2.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(anglesLeftKnee, self.__xWindowSize))
            self.__ln3.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(anglesLeftAnkle, self.__xWindowSize))
            self.__ln4.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(anglesRightHip, self.__xWindowSize))
            self.__ln5.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(anglesRightKnee, self.__xWindowSize)) 
            self.__ln6.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(anglesRightAnkle, self.__xWindowSize))
        elif self.__valuetype == "raw_position":
            rawPositionLeftHip = self.__udpClient.getRawPositionLeftHip()
            rawPositionLeftKnee = self.__udpClient.getRawPositionLeftKnee()
            rawPositionLeftAnkle = self.__udpClient.getRawPositionLeftAnkle()
            rawPositionRightHip = self.__udpClient.getRawPositionRightHip()
            rawPositionRightKnee = self.__udpClient.getRawPositionRightKnee()
            rawPositionRightAnkle = self.__udpClient.getRawPositionRightAnkle()
        
            self.__ln1.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(rawPositionLeftHip, self.__xWindowSize))       #the time axis is mapped to begin with "0.0" for the first sensor value
            self.__ln2.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(rawPositionLeftKnee, self.__xWindowSize))
            self.__ln3.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(rawPositionLeftAnkle, self.__xWindowSize))
            self.__ln4.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(rawPositionRightHip, self.__xWindowSize))
            self.__ln5.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(rawPositionRightKnee, self.__xWindowSize)) 
            self.__ln6.set_data([timeValue - self.__timeZero for timeValue in self.cutOutValues(timeValues, self.__xWindowSize)], self.cutOutValues(rawPositionRightAnkle, self.__xWindowSize))
        self.__sub1.relim()
        self.__sub1.autoscale_view()
        self.__sub2.relim()
        self.__sub2.autoscale_view()
        self.__sub3.relim()
        self.__sub3.autoscale_view()
        self.__sub4.relim()
        self.__sub4.autoscale_view()
        self.__sub5.relim()
        self.__sub5.autoscale_view()
        self.__sub6.relim()
        self.__sub6.autoscale_view()
        #self.__fig.canvas.resize_event()
        return self.__ln1, self.__ln2, self.__ln3, self.__ln4, self.__ln5, self.__ln6,

    def cutOutValues(self, values, quantity):
        valuesCutout = []
        if(len(values) > quantity):
            for n in range(0, quantity):
                n_inv = quantity-n
                valuesCutout.append(values[-n_inv])
        else:
            for n in range(0, len(values)):
                valuesCutout.append(values[n])
        return valuesCutout

    def stopPlotting(self):
        self.__stopFlag = True
    
    def restartPlotting(self):
        self.__stopFlag = False
        self.__ani.event_source.start()

    def getFigure(self):
        return self.__fig

    def setXWindowSize(self, windowSize):
        self.__xWindowSize = windowSize

    
