import UDPClient
import Plotter
import Logger
import GUI
from queue import Queue
import matplotlib.pyplot as plt
import sys
import wx
import time

def main():
    print("Hello")
    ipAddress = ""
    port = 0
    app = wx.App()
    while(ipAddress == "" or port == 0):
        startframe = GUI.StartFrame()   
        startframe.Show()
        app.MainLoop()
        ipAddress = startframe.getIPAddress()
        port = startframe.getPort()
    print("IP address:", ipAddress)
    print("Port:", port)
    client = UDPClient.UDPClient(ipAddress, port)
    client.start()
    plotter = Plotter.Plotter(client, "raw_position")
    logger = Logger.Logger(client, "raw_position")
    plotFrame = GUI.PlotFrame(plotter, logger, app)
    logger.start()
    plotFrame.start()
    #stopframe = GUI.StopFrame(plotter, app)
    #stopframe.start()
    plotter.startPlotting()
    while(1):
        if(input() == "stop"): break
    print(client.getReceivedUDPMessages())
    client.stop()
    client.join()
    print("Exit")
    sys.exit()
    
    
    print("Hello")


if __name__ == "__main__":
    main()


