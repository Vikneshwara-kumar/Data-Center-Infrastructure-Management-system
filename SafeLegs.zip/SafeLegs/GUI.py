import wx
import threading
import time
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.backends.backend_wxagg import NavigationToolbar2WxAgg as NavigationToolbar

class StartFrame(wx.Frame):
    def __init__(self):
        super().__init__(parent = None, title = "Remote Sensor Value Display", size = (310, 200))
        self.__ipAddress = ""
        self.__port = 0
        self.__panel = wx.Panel(self)
        self.__ipLabel = wx.StaticText(self.__panel, label = "IP address", pos = (20,25))
        self.__ipEntry = wx.TextCtrl(self.__panel, pos = (100, 20), size = (190, 30))
        self.__portLabel = wx.StaticText(self.__panel, label = "Port", pos = (20, 65))
        self.__portEntry = wx.TextCtrl(self.__panel, pos = (100, 60), size = (190, 30))
        self.__startButton = wx.Button(self.__panel, label = "Start collecting data", pos = (20, 120), size = (270, 30))
        self.__startButton.Bind(wx.EVT_BUTTON, self.onStartButtonPressed)

    def onStartButtonPressed(self, event):
        self.readEntries()
        self.Close()

    def readEntries(self):
        self.__ipAddress = self.__ipEntry.GetValue()
        portString = self.__portEntry.GetValue()
        if(portString != ""):
            self.__port = int(portString)

    def getIPAddress(self):
        return self.__ipAddress

    def getPort(self):
        return self.__port

class PlotFrame(wx.Frame, threading.Thread):
    def __init__(self, plotter, logger, app):
        super().__init__(parent = None, title = "Remote Sensor Value Display", size = (1470, 875))
        threading.Thread.__init__(self)
        self.__plotter = plotter
        self.__logger = logger
        self.__app = app
        self.__sizerVertical = wx.BoxSizer(wx.VERTICAL)
        self.__sizerHorizontal = wx.BoxSizer(wx.HORIZONTAL)
        self.__controlPanel = wx.Panel(self)
        self.__figurePanel = FigureCanvas(self, -1, plotter.getFigure())
        self.__navigationToolbar = NavigationToolbar(self.__figurePanel)
        self.__startButton = wx.Button(self.__controlPanel, label = "Start plotting data", pos = (15, 10), size = (230, 30))
        self.__startButton.Bind(wx.EVT_BUTTON, self.onStartButtonPressed)
        self.__stopButton = wx.Button(self.__controlPanel, label = "Stop plotting data", pos = (15, 50), size = (230, 30))
        self.__stopButton.Bind(wx.EVT_BUTTON, self.onStopButtonPressed)
        self.__xWindowSizeLabel = wx.StaticText(self.__controlPanel, label = "Set size of plotted time interval:\n[amount of plotted values]", pos = (15, 120), size = (230, -1), style = wx.ALIGN_LEFT | wx.ST_ELLIPSIZE_MIDDLE)
        self.__xWindowSizeLabel.SetFont(wx.Font(9, wx.NORMAL, wx.NORMAL, wx.BOLD))
        self.__xWindowSizeSlider = wx.Slider(self.__controlPanel, value = 1000, minValue = 1, maxValue = 1000, pos = (25, 160), size = (210, -1), style=wx.SL_HORIZONTAL | wx.SL_AUTOTICKS | wx.SL_LABELS)
        self.__xWindowSizeSlider.Bind(wx.EVT_SLIDER, self.onXWindowSizeSliderScroll)
        self.__sizerVertical.Add(self.__figurePanel, 0, 10)
        self.__sizerVertical.Add(self.__navigationToolbar, 0, 10)
        self.__sizerHorizontal.Add(self.__sizerVertical, 0, 10)
        self.__sizerHorizontal.Add(self.__controlPanel, 0, 10)
        self.SetSizer(self.__sizerHorizontal)
        self.Bind(wx.EVT_CLOSE, self.onClose)   #the "x" button (for closing the window) has to be redirected, because the plotter has to be stopped before closing the window

    def run(self):
        self.Show()
        self.__app.MainLoop()

    def onClose(self, event):
        self.__plotter.stopPlotting()
        self.__logger.stopLogging()
        self.Destroy()

    def onStartButtonPressed(self, event):
        self.__plotter.restartPlotting()

    def onStopButtonPressed(self, event):
        self.__plotter.stopPlotting()

    def onXWindowSizeSliderScroll(self, event):
        self.__plotter.setXWindowSize(self.__xWindowSizeSlider.GetValue())

class StopFrame(wx.Frame, threading.Thread):
    def __init__(self, plotter, app):
        super().__init__(parent = None, title = "Remote Sensor Value Display", size = (310, 200))
        threading.Thread.__init__(self)
        self.__app = app
        self.__panel = wx.Panel(self)
        self.__stopButton = wx.Button(self.__panel, label = "Stop collecting data", pos = (20, 120), size = (270, 30))
        self.__stopButton.Bind(wx.EVT_BUTTON, self.onStopButtonPressed)
    
    def run(self):
        self.Show()
        self.__app.MainLoop()
    
    def onStopButtonPressed(self, event):
        self.__plotter.stopPlotting()
        self.Close()
